import React from "react";
import { View, Text } from "react-native";

const Setup2 = () => (
  <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
    <Text>Setup 2 Screen</Text>
  </View>
);

export default Setup2;